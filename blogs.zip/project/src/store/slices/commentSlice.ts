import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface Comment {
  id: string;
  content: string;
  author: {
    id: string;
    name: string;
    avatar: string;
  };
  blogId: string;
  createdAt: string;
  likes: number;
  likedBy: string[];
}

interface CommentState {
  comments: { [blogId: string]: Comment[] };
  loading: boolean;
}

const initialState: CommentState = {
  comments: {},
  loading: false,
};

const commentSlice = createSlice({
  name: 'comments',
  initialState,
  reducers: {
    setComments: (state, action: PayloadAction<{ blogId: string; comments: Comment[] }>) => {
      state.comments[action.payload.blogId] = action.payload.comments;
    },
    addComment: (state, action: PayloadAction<Comment>) => {
      const blogId = action.payload.blogId;
      if (!state.comments[blogId]) {
        state.comments[blogId] = [];
      }
      state.comments[blogId].push(action.payload);
    },
    deleteComment: (state, action: PayloadAction<{ blogId: string; commentId: string }>) => {
      const { blogId, commentId } = action.payload;
      if (state.comments[blogId]) {
        state.comments[blogId] = state.comments[blogId].filter(c => c.id !== commentId);
      }
    },
    toggleCommentLike: (state, action: PayloadAction<{ blogId: string; commentId: string; userId: string }>) => {
      const { blogId, commentId, userId } = action.payload;
      const comment = state.comments[blogId]?.find(c => c.id === commentId);
      if (comment) {
        const isLiked = comment.likedBy.includes(userId);
        if (isLiked) {
          comment.likedBy = comment.likedBy.filter(id => id !== userId);
          comment.likes--;
        } else {
          comment.likedBy.push(userId);
          comment.likes++;
        }
      }
    },
  },
});

export const { setComments, addComment, deleteComment, toggleCommentLike } = commentSlice.actions;
export default commentSlice.reducer;