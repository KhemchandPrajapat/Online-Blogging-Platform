import { createSlice, PayloadAction } from '@reduxjs/toolkit';

export interface Blog {
  id: string;
  title: string;
  content: string;
  excerpt: string;
  author: {
    id: string;
    name: string;
    avatar: string;
  };
  category: string;
  tags: string[];
  likes: number;
  likedBy: string[];
  commentsCount: number;
  createdAt: string;
  updatedAt: string;
  coverImage?: string;
  published: boolean;
}

interface BlogState {
  blogs: Blog[];
  currentBlog: Blog | null;
  userBlogs: Blog[];
  loading: boolean;
  searchTerm: string;
  selectedCategory: string;
  categories: string[];
}

const initialState: BlogState = {
  blogs: [],
  currentBlog: null,
  userBlogs: [],
  loading: false,
  searchTerm: '',
  selectedCategory: '',
  categories: ['Technology', 'Lifestyle', 'Travel', 'Food', 'Health', 'Business', 'Education'],
};

const blogSlice = createSlice({
  name: 'blogs',
  initialState,
  reducers: {
    setBlogs: (state, action: PayloadAction<Blog[]>) => {
      state.blogs = action.payload;
    },
    addBlog: (state, action: PayloadAction<Blog>) => {
      state.blogs.unshift(action.payload);
      state.userBlogs.unshift(action.payload);
    },
    updateBlog: (state, action: PayloadAction<Blog>) => {
      const index = state.blogs.findIndex(blog => blog.id === action.payload.id);
      if (index !== -1) {
        state.blogs[index] = action.payload;
      }
      const userIndex = state.userBlogs.findIndex(blog => blog.id === action.payload.id);
      if (userIndex !== -1) {
        state.userBlogs[userIndex] = action.payload;
      }
    },
    deleteBlog: (state, action: PayloadAction<string>) => {
      state.blogs = state.blogs.filter(blog => blog.id !== action.payload);
      state.userBlogs = state.userBlogs.filter(blog => blog.id !== action.payload);
    },
    setCurrentBlog: (state, action: PayloadAction<Blog | null>) => {
      state.currentBlog = action.payload;
    },
    toggleLike: (state, action: PayloadAction<{ blogId: string; userId: string }>) => {
      const blog = state.blogs.find(b => b.id === action.payload.blogId);
      if (blog) {
        const isLiked = blog.likedBy.includes(action.payload.userId);
        if (isLiked) {
          blog.likedBy = blog.likedBy.filter(id => id !== action.payload.userId);
          blog.likes--;
        } else {
          blog.likedBy.push(action.payload.userId);
          blog.likes++;
        }
      }
    },
    setSearchTerm: (state, action: PayloadAction<string>) => {
      state.searchTerm = action.payload;
    },
    setSelectedCategory: (state, action: PayloadAction<string>) => {
      state.selectedCategory = action.payload;
    },
    setUserBlogs: (state, action: PayloadAction<Blog[]>) => {
      state.userBlogs = action.payload;
    },
  },
});

export const {
  setBlogs,
  addBlog,
  updateBlog,
  deleteBlog,
  setCurrentBlog,
  toggleLike,
  setSearchTerm,
  setSelectedCategory,
  setUserBlogs,
} = blogSlice.actions;
export default blogSlice.reducer;