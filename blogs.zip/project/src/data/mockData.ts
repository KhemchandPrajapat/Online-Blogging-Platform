import { Blog } from '../store/slices/blogSlice';
import { Comment } from '../store/slices/commentSlice';
import { User } from '../store/slices/authSlice';

export const mockUsers: User[] = [
  {
    id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
    bio: 'Tech enthusiast and blogger',
    role: 'user',
    joinedAt: '2024-01-15',
  },
  {
    id: '2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
    bio: 'UX Designer and writer',
    role: 'user',
    joinedAt: '2024-02-01',
  },
  {
    id: '3',
    name: 'Admin User',
    email: 'admin@blog.com',
    avatar: 'https://images.pexels.com/photos/1040880/pexels-photo-1040880.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
    bio: 'Platform administrator',
    role: 'admin',
    joinedAt: '2024-01-01',
  },
];

export const mockBlogs: Blog[] = [
  {
    id: '1',
    title: 'The Future of Web Development',
    content: '<p>Web development is constantly evolving. In this comprehensive guide, we explore the latest trends, technologies, and best practices that are shaping the future of web development.</p><p>From React and Vue.js to serverless architectures and JAMstack, the landscape is rich with opportunities for developers to create amazing user experiences.</p><p>One of the most exciting developments is the rise of full-stack frameworks like Next.js and Nuxt.js, which enable developers to build both frontend and backend functionality with a single codebase.</p>',
    excerpt: 'Exploring the latest trends and technologies shaping the future of web development.',
    author: mockUsers[0],
    category: 'Technology',
    tags: ['web development', 'react', 'javascript'],
    likes: 24,
    likedBy: ['2', '3'],
    commentsCount: 5,
    createdAt: '2024-12-10T08:00:00Z',
    updatedAt: '2024-12-10T08:00:00Z',
    coverImage: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&dpr=1',
    published: true,
  },
  {
    id: '2',
    title: 'Designing for Accessibility',
    content: '<p>Accessibility is not just a requirement—it\'s a responsibility. Creating inclusive digital experiences ensures that everyone, regardless of their abilities, can access and interact with your content.</p><p>In this article, we\'ll cover practical tips and techniques for designing accessible websites and applications, from color contrast to keyboard navigation.</p>',
    excerpt: 'A comprehensive guide to creating inclusive digital experiences for all users.',
    author: mockUsers[1],
    category: 'Design',
    tags: ['accessibility', 'ux design', 'inclusive design'],
    likes: 18,
    likedBy: ['1', '3'],
    commentsCount: 3,
    createdAt: '2024-12-09T14:30:00Z',
    updatedAt: '2024-12-09T14:30:00Z',
    coverImage: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&dpr=1',
    published: true,
  },
  {
    id: '3',
    title: 'Building Scalable React Applications',
    content: '<p>As React applications grow in complexity, it becomes crucial to implement patterns and practices that ensure scalability and maintainability.</p><p>This guide covers advanced React patterns, state management with Redux, performance optimization techniques, and architectural decisions that will help your application scale effectively.</p>',
    excerpt: 'Learn advanced patterns and practices for building scalable React applications.',
    author: mockUsers[0],
    category: 'Technology',
    tags: ['react', 'redux', 'scalability'],
    likes: 32,
    likedBy: ['1', '2'],
    commentsCount: 8,
    createdAt: '2024-12-08T10:15:00Z',
    updatedAt: '2024-12-08T10:15:00Z',
    coverImage: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&dpr=1',
    published: true,
  },
];

export const mockComments: { [blogId: string]: Comment[] } = {
  '1': [
    {
      id: '1',
      content: 'Great article! Really enjoyed the insights on JAMstack.',
      author: mockUsers[1],
      blogId: '1',
      createdAt: '2024-12-10T09:00:00Z',
      likes: 3,
      likedBy: ['1'],
    },
    {
      id: '2',
      content: 'Thanks for sharing this comprehensive overview. Very helpful!',
      author: mockUsers[2],
      blogId: '1',
      createdAt: '2024-12-10T10:30:00Z',
      likes: 1,
      likedBy: [],
    },
  ],
  '2': [
    {
      id: '3',
      content: 'Accessibility is so important. Thanks for the practical tips!',
      author: mockUsers[0],
      blogId: '2',
      createdAt: '2024-12-09T15:00:00Z',
      likes: 2,
      likedBy: ['2'],
    },
  ],
  '3': [
    {
      id: '4',
      content: 'Excellent deep dive into React architecture. Bookmarked!',
      author: mockUsers[1],
      blogId: '3',
      createdAt: '2024-12-08T11:00:00Z',
      likes: 5,
      likedBy: ['1', '3'],
    },
  ],
};