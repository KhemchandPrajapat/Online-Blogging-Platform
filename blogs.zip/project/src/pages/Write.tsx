import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { useAuth } from '../hooks/useAuth';
import { addBlog } from '../store/slices/blogSlice';
import BlogEditor from '../components/Blog/BlogEditor';

const Write: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Sign in to write
          </h2>
          <p className="text-gray-600 mb-6">
            You need to be signed in to create blog posts.
          </p>
          <a
            href="/login"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const handleSave = (data: {
    title: string;
    content: string;
    category: string;
    tags: string[];
    excerpt: string;
  }) => {
    if (!user) return;

    const newBlog = {
      id: Date.now().toString(),
      title: data.title,
      content: data.content,
      excerpt: data.excerpt,
      author: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
      },
      category: data.category,
      tags: data.tags,
      likes: 0,
      likedBy: [],
      commentsCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      published: true,
    };

    dispatch(addBlog(newBlog));
    navigate(`/blog/${newBlog.id}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <BlogEditor onSave={handleSave} />
    </div>
  );
};

export default Write;