import React, { useState, useEffect } from 'react';
import { User, Mail, Calendar, Edit2, Save, X } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { setUserBlogs } from '../store/slices/blogSlice';
import { updateProfile } from '../store/slices/authSlice';
import BlogCard from '../components/Blog/BlogCard';

const Profile: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  const userBlogs = useSelector((state: RootState) => state.blogs.userBlogs);
  const allBlogs = useSelector((state: RootState) => state.blogs.blogs);
  
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
  });

  useEffect(() => {
    if (user) {
      // Filter blogs by current user
      const myBlogs = allBlogs.filter(blog => blog.author.id === user.id);
      dispatch(setUserBlogs(myBlogs));
    }
  }, [user, allBlogs, dispatch]);

  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Sign in required
          </h2>
          <p className="text-gray-600 mb-6">
            Please sign in to view your profile.
          </p>
          <a
            href="/login"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const handleEditSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    dispatch(updateProfile(editForm));
    setIsEditing(false);
  };

  const handleEditCancel = () => {
    setEditForm({
      name: user.name,
      bio: user.bio || '',
    });
    setIsEditing(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Profile Header */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 mb-8">
          <div className="p-8">
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-4 md:space-y-0 md:space-x-8">
              <div className="flex-shrink-0">
                <img
                  src={user.avatar}
                  alt={user.name}
                  className="h-24 w-24 rounded-full object-cover"
                />
              </div>
              
              <div className="flex-1 min-w-0">
                {isEditing ? (
                  <form onSubmit={handleEditSubmit} className="space-y-4">
                    <div>
                      <input
                        type="text"
                        value={editForm.name}
                        onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                        className="text-2xl font-bold text-gray-900 bg-transparent border-b border-gray-300 focus:border-blue-500 outline-none"
                        placeholder="Your name"
                      />
                    </div>
                    <div>
                      <textarea
                        value={editForm.bio}
                        onChange={(e) => setEditForm({ ...editForm, bio: e.target.value })}
                        rows={3}
                        className="w-full text-gray-600 bg-transparent border border-gray-300 rounded-md px-3 py-2 focus:border-blue-500 outline-none resize-none"
                        placeholder="Tell us about yourself..."
                      />
                    </div>
                    <div className="flex space-x-3">
                      <button
                        type="submit"
                        className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors"
                      >
                        <Save className="h-4 w-4" />
                        <span>Save</span>
                      </button>
                      <button
                        type="button"
                        onClick={handleEditCancel}
                        className="flex items-center space-x-2 bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 transition-colors"
                      >
                        <X className="h-4 w-4" />
                        <span>Cancel</span>
                      </button>
                    </div>
                  </form>
                ) : (
                  <>
                    <div className="flex items-center space-x-4 mb-2">
                      <h1 className="text-2xl font-bold text-gray-900">{user.name}</h1>
                      <button
                        onClick={() => setIsEditing(true)}
                        className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                    </div>
                    <p className="text-gray-600 mb-4">
                      {user.bio || 'No bio added yet.'}
                    </p>
                  </>
                )}
                
                <div className="flex flex-wrap items-center gap-6 text-sm text-gray-500">
                  <div className="flex items-center space-x-2">
                    <Mail className="h-4 w-4" />
                    <span>{user.email}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="h-4 w-4" />
                    <span>Joined {new Date(user.joinedAt).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4" />
                    <span className="capitalize">{user.role}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="border-t border-gray-200 px-8 py-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{userBlogs.length}</div>
                <div className="text-gray-600">Posts Published</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {userBlogs.reduce((acc, blog) => acc + blog.likes, 0)}
                </div>
                <div className="text-gray-600">Total Likes</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">
                  {userBlogs.reduce((acc, blog) => acc + blog.commentsCount, 0)}
                </div>
                <div className="text-gray-600">Total Comments</div>
              </div>
            </div>
          </div>
        </div>

        {/* User's Blog Posts */}
        <div>
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Your Blog Posts</h2>
          
          {userBlogs.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {userBlogs.map(blog => (
                <BlogCard key={blog.id} blog={blog} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg shadow-sm border border-gray-200">
              <div className="text-gray-400 mb-4">
                <Edit2 className="h-16 w-16 mx-auto" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">No posts yet</h3>
              <p className="text-gray-600 mb-6">
                Start writing your first blog post to share your thoughts with the world.
              </p>
              <a
                href="/write"
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors inline-block"
              >
                Write Your First Post
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Profile;