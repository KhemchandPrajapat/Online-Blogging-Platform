import React, { useState } from 'react';
import { Users, FileText, Shield, Trash2, Edit, MoreVertical } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { useAuth } from '../hooks/useAuth';
import { deleteBlog } from '../store/slices/blogSlice';
import { setUsers, updateUserRole, deleteUser } from '../store/slices/userSlice';
import { mockUsers } from '../data/mockData';
import { formatDistanceToNow } from 'date-fns';

const Admin: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  const blogs = useSelector((state: RootState) => state.blogs.blogs);
  const users = useSelector((state: RootState) => state.users.users);
  
  const [activeTab, setActiveTab] = useState<'posts' | 'users'>('posts');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);

  React.useEffect(() => {
    // Load users data
    dispatch(setUsers(mockUsers));
  }, [dispatch]);

  if (!isAuthenticated || user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <Shield className="h-16 w-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Access Denied
          </h2>
          <p className="text-gray-600 mb-6">
            You need admin privileges to access this page.
          </p>
          <a
            href="/"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Go Home
          </a>
        </div>
      </div>
    );
  }

  const handleDeleteBlog = (blogId: string) => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      dispatch(deleteBlog(blogId));
    }
  };

  const handleDeleteUser = (userId: string) => {
    if (window.confirm('Are you sure you want to delete this user?')) {
      dispatch(deleteUser(userId));
    }
  };

  const handleUserRoleChange = (userId: string, newRole: 'user' | 'admin') => {
    dispatch(updateUserRole({ userId, role: newRole }));
  };

  const toggleSelectItem = (itemId: string) => {
    setSelectedItems(prev => 
      prev.includes(itemId) 
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const selectAllItems = () => {
    const allIds = activeTab === 'posts' 
      ? blogs.map(blog => blog.id)
      : users.map(user => user.id);
    setSelectedItems(selectedItems.length === allIds.length ? [] : allIds);
  };

  const handleBulkDelete = () => {
    if (selectedItems.length === 0) return;
    
    if (window.confirm(`Are you sure you want to delete ${selectedItems.length} items?`)) {
      selectedItems.forEach(itemId => {
        if (activeTab === 'posts') {
          dispatch(deleteBlog(itemId));
        } else {
          dispatch(deleteUser(itemId));
        }
      });
      setSelectedItems([]);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage blog posts and users</p>
        </div>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <FileText className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{blogs.length}</p>
                <p className="text-gray-600 text-sm">Total Posts</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Users className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{users.length}</p>
                <p className="text-gray-600 text-sm">Total Users</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <Shield className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {users.filter(u => u.role === 'admin').length}
                </p>
                <p className="text-gray-600 text-sm">Admins</p>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          {/* Tabs */}
          <div className="border-b border-gray-200">
            <nav className="flex space-x-8 px-6">
              <button
                onClick={() => {
                  setActiveTab('posts');
                  setSelectedItems([]);
                }}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'posts'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } transition-colors`}
              >
                <FileText className="h-5 w-5 inline mr-2" />
                Blog Posts
              </button>
              <button
                onClick={() => {
                  setActiveTab('users');
                  setSelectedItems([]);
                }}
                className={`py-4 px-1 border-b-2 font-medium text-sm ${
                  activeTab === 'users'
                    ? 'border-blue-500 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                } transition-colors`}
              >
                <Users className="h-5 w-5 inline mr-2" />
                Users
              </button>
            </nav>
          </div>

          {/* Bulk Actions */}
          {selectedItems.length > 0 && (
            <div className="px-6 py-4 bg-blue-50 border-b border-blue-200">
              <div className="flex items-center justify-between">
                <span className="text-sm text-blue-700">
                  {selectedItems.length} items selected
                </span>
                <button
                  onClick={handleBulkDelete}
                  className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors text-sm"
                >
                  Delete Selected
                </button>
              </div>
            </div>
          )}

          {/* Content */}
          <div className="p-6">
            {activeTab === 'posts' ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-semibold text-gray-900">Blog Posts Management</h2>
                  <button
                    onClick={selectAllItems}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    {selectedItems.length === blogs.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="space-y-4">
                  {blogs.map(blog => (
                    <div key={blog.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-start space-x-4">
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(blog.id)}
                          onChange={() => toggleSelectItem(blog.id)}
                          className="mt-1 h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <div className="flex-1">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="text-lg font-medium text-gray-900">{blog.title}</h3>
                              <p className="text-gray-600 text-sm mt-1">{blog.excerpt}</p>
                              <div className="flex items-center space-x-4 mt-2 text-sm text-gray-500">
                                <span>By {blog.author.name}</span>
                                <span>{formatDistanceToNow(new Date(blog.createdAt), { addSuffix: true })}</span>
                                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                                  {blog.category}
                                </span>
                                <span>{blog.likes} likes</span>
                                <span>{blog.commentsCount} comments</span>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <button
                                onClick={() => window.open(`/blog/${blog.id}`, '_blank')}
                                className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteBlog(blog.id)}
                                className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h2 className="text-lg font-semibold text-gray-900">Users Management</h2>
                  <button
                    onClick={selectAllItems}
                    className="text-sm text-blue-600 hover:text-blue-700"
                  >
                    {selectedItems.length === users.length ? 'Deselect All' : 'Select All'}
                  </button>
                </div>

                <div className="space-y-4">
                  {users.map(userData => (
                    <div key={userData.id} className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center space-x-4">
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(userData.id)}
                          onChange={() => toggleSelectItem(userData.id)}
                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                        />
                        <img
                          src={userData.avatar}
                          alt={userData.name}
                          className="h-12 w-12 rounded-full object-cover"
                        />
                        <div className="flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <h3 className="text-lg font-medium text-gray-900">{userData.name}</h3>
                              <p className="text-gray-600 text-sm">{userData.email}</p>
                              <p className="text-gray-500 text-xs mt-1">
                                Joined {new Date(userData.joinedAt).toLocaleDateString()}
                              </p>
                            </div>
                            <div className="flex items-center space-x-4">
                              <select
                                value={userData.role}
                                onChange={(e) => handleUserRoleChange(userData.id, e.target.value as 'user' | 'admin')}
                                className="text-sm border border-gray-300 rounded-md px-2 py-1 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                              >
                                <option value="user">User</option>
                                <option value="admin">Admin</option>
                              </select>
                              {userData.id !== user?.id && (
                                <button
                                  onClick={() => handleDeleteUser(userData.id)}
                                  className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Admin;