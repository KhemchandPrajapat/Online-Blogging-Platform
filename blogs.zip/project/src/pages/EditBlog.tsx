import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { useAuth } from '../hooks/useAuth';
import { updateBlog } from '../store/slices/blogSlice';
import BlogEditor from '../components/Blog/BlogEditor';

const EditBlog: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const blog = useSelector((state: RootState) => 
    state.blogs.blogs.find(b => b.id === id)
  );

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Sign in required
          </h2>
          <p className="text-gray-600 mb-6">
            You need to be signed in to edit blog posts.
          </p>
          <a
            href="/login"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  if (!blog) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Blog not found</h2>
          <p className="text-gray-600 mt-2">The blog post you're trying to edit doesn't exist.</p>
          <button
            onClick={() => navigate('/')}
            className="mt-4 text-blue-600 hover:text-blue-700 transition-colors"
          >
            ← Back to home
          </button>
        </div>
      </div>
    );
  }

  // Check if user can edit this blog
  if (user?.id !== blog.author.id && user?.role !== 'admin') {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Access denied
          </h2>
          <p className="text-gray-600 mb-6">
            You don't have permission to edit this blog post.
          </p>
          <button
            onClick={() => navigate(`/blog/${blog.id}`)}
            className="bg-gray-600 text-white px-6 py-3 rounded-lg hover:bg-gray-700 transition-colors"
          >
            View Blog
          </button>
        </div>
      </div>
    );
  }

  const handleSave = (data: {
    title: string;
    content: string;
    category: string;
    tags: string[];
    excerpt: string;
  }) => {
    const updatedBlog = {
      ...blog,
      title: data.title,
      content: data.content,
      excerpt: data.excerpt,
      category: data.category,
      tags: data.tags,
      updatedAt: new Date().toISOString(),
    };

    dispatch(updateBlog(updatedBlog));
    navigate(`/blog/${blog.id}`);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <BlogEditor
        initialTitle={blog.title}
        initialContent={blog.content}
        initialCategory={blog.category}
        initialTags={blog.tags}
        onSave={handleSave}
        isEditing={true}
      />
    </div>
  );
};

export default EditBlog;