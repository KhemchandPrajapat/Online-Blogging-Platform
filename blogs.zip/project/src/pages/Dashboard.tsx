import React from 'react';
import { Link } from 'react-router-dom';
import { PenTool, Eye, Heart, MessageCircle, TrendingUp, Edit, Trash2 } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { useAuth } from '../hooks/useAuth';
import { deleteBlog } from '../store/slices/blogSlice';
import { formatDistanceToNow } from 'date-fns';

const Dashboard: React.FC = () => {
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  const allBlogs = useSelector((state: RootState) => state.blogs.blogs);
  
  if (!isAuthenticated || !user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="bg-white p-8 rounded-lg shadow-md text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">
            Sign in required
          </h2>
          <p className="text-gray-600 mb-6">
            Please sign in to access your dashboard.
          </p>
          <a
            href="/login"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In
          </a>
        </div>
      </div>
    );
  }

  const userBlogs = allBlogs.filter(blog => blog.author.id === user.id);
  const totalLikes = userBlogs.reduce((acc, blog) => acc + blog.likes, 0);
  const totalComments = userBlogs.reduce((acc, blog) => acc + blog.commentsCount, 0);

  const handleDeleteBlog = (blogId: string, blogTitle: string) => {
    if (window.confirm(`Are you sure you want to delete "${blogTitle}"?`)) {
      dispatch(deleteBlog(blogId));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-1">Manage your blog posts and track performance</p>
          </div>
          <Link
            to="/write"
            className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2"
          >
            <PenTool className="h-5 w-5" />
            <span>New Post</span>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-blue-100 rounded-lg">
                <PenTool className="h-6 w-6 text-blue-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{userBlogs.length}</p>
                <p className="text-gray-600 text-sm">Total Posts</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-green-100 rounded-lg">
                <Eye className="h-6 w-6 text-green-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">
                  {userBlogs.reduce((acc, blog) => acc + Math.ceil(blog.content.replace(/<[^>]*>/g, '').length / 200) * 100, 0)}
                </p>
                <p className="text-gray-600 text-sm">Est. Views</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-red-100 rounded-lg">
                <Heart className="h-6 w-6 text-red-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{totalLikes}</p>
                <p className="text-gray-600 text-sm">Total Likes</p>
              </div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
            <div className="flex items-center space-x-3">
              <div className="p-2 bg-purple-100 rounded-lg">
                <MessageCircle className="h-6 w-6 text-purple-600" />
              </div>
              <div>
                <p className="text-2xl font-bold text-gray-900">{totalComments}</p>
                <p className="text-gray-600 text-sm">Total Comments</p>
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-8">
          <h2 className="text-xl font-semibold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link
              to="/write"
              className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <PenTool className="h-6 w-6 text-blue-600" />
              <div>
                <h3 className="font-medium text-gray-900">Write New Post</h3>
                <p className="text-sm text-gray-600">Create a new blog post</p>
              </div>
            </Link>

            <Link
              to="/profile"
              className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <TrendingUp className="h-6 w-6 text-green-600" />
              <div>
                <h3 className="font-medium text-gray-900">View Profile</h3>
                <p className="text-sm text-gray-600">Manage your profile</p>
              </div>
            </Link>

            <Link
              to="/explore"
              className="flex items-center space-x-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <Eye className="h-6 w-6 text-purple-600" />
              <div>
                <h3 className="font-medium text-gray-900">Explore Posts</h3>
                <p className="text-sm text-gray-600">Discover new content</p>
              </div>
            </Link>
          </div>
        </div>

        {/* Recent Posts */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">Your Recent Posts</h2>
          </div>
          
          {userBlogs.length > 0 ? (
            <div className="divide-y divide-gray-200">
              {userBlogs.slice(0, 5).map(blog => (
                <div key={blog.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <Link
                        to={`/blog/${blog.id}`}
                        className="text-lg font-medium text-gray-900 hover:text-blue-600 transition-colors"
                      >
                        {blog.title}
                      </Link>
                      <p className="text-gray-600 text-sm mt-1 line-clamp-2">
                        {blog.excerpt}
                      </p>
                      <div className="flex items-center space-x-4 mt-3 text-sm text-gray-500">
                        <span>{formatDistanceToNow(new Date(blog.createdAt), { addSuffix: true })}</span>
                        <span className="flex items-center space-x-1">
                          <Heart className="h-4 w-4" />
                          <span>{blog.likes}</span>
                        </span>
                        <span className="flex items-center space-x-1">
                          <MessageCircle className="h-4 w-4" />
                          <span>{blog.commentsCount}</span>
                        </span>
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs">
                          {blog.category}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2 ml-4">
                      <Link
                        to={`/edit/${blog.id}`}
                        className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <Edit className="h-4 w-4" />
                      </Link>
                      <button
                        onClick={() => handleDeleteBlog(blog.id, blog.title)}
                        className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="p-12 text-center">
              <PenTool className="h-16 w-16 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No posts yet</h3>
              <p className="text-gray-600 mb-6">
                Get started by writing your first blog post.
              </p>
              <Link
                to="/write"
                className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors"
              >
                Write Your First Post
              </Link>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;