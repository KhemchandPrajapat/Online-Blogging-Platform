import React from 'react';
import { Link } from 'react-router-dom';
import { PenTool, TrendingUp, Users, BookOpen } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center">
          <div className="flex justify-center mb-6">
            <div className="p-3 bg-blue-500 bg-opacity-20 rounded-full">
              <PenTool className="h-12 w-12" />
            </div>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
            Share Your Stories
            <br />
            <span className="text-blue-200">Inspire the World</span>
          </h1>
          
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
            Join our community of passionate writers and readers. Create beautiful blog posts, 
            connect with like-minded people, and build your audience.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6 mb-12">
            <Link
              to="/register"
              className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition-all duration-200 transform hover:scale-105"
            >
              Start Writing Today
            </Link>
            <Link
              to="/explore"
              className="border-2 border-blue-200 text-blue-100 px-8 py-3 rounded-lg font-semibold hover:bg-blue-200 hover:text-blue-900 transition-colors"
            >
              Explore Stories
            </Link>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <Users className="h-8 w-8 text-blue-300" />
              </div>
              <div className="text-2xl font-bold mb-1">10K+</div>
              <div className="text-blue-200">Active Writers</div>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <BookOpen className="h-8 w-8 text-blue-300" />
              </div>
              <div className="text-2xl font-bold mb-1">50K+</div>
              <div className="text-blue-200">Stories Published</div>
            </div>
            <div className="text-center">
              <div className="flex justify-center mb-3">
                <TrendingUp className="h-8 w-8 text-blue-300" />
              </div>
              <div className="text-2xl font-bold mb-1">1M+</div>
              <div className="text-blue-200">Monthly Reads</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;