import React from 'react';
import { Link } from 'react-router-dom';
import { PenTool, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <PenTool className="h-8 w-8 text-blue-400" />
              <span className="text-xl font-bold">BlogCraft</span>
            </Link>
            <p className="text-gray-400 text-sm">
              A modern blogging platform for creators to share their stories and connect with readers worldwide.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/explore" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Explore
                </Link>
              </li>
              <li>
                <Link to="/write" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Write
                </Link>
              </li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <ul className="space-y-2">
              <li>
                <Link to="/explore?category=Technology" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Technology
                </Link>
              </li>
              <li>
                <Link to="/explore?category=Design" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Design
                </Link>
              </li>
              <li>
                <Link to="/explore?category=Lifestyle" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Lifestyle
                </Link>
              </li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h3 className="font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Help Center
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Contact Us
                </a>
              </li>
              <li>
                <a href="#" className="text-gray-400 hover:text-white transition-colors text-sm">
                  Privacy Policy
                </a>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col sm:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">
            © 2024 BlogCraft. All rights reserved.
          </p>
          <p className="flex items-center space-x-1 text-gray-400 text-sm mt-2 sm:mt-0">
            <span>Made with</span>
            <Heart className="h-4 w-4 text-red-500" />
            <span>by developers for creators</span>
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;