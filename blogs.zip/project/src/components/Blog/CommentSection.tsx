import React, { useState } from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, Send } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../store';
import { useAuth } from '../../hooks/useAuth';
import { addComment, toggleCommentLike } from '../../store/slices/commentSlice';

interface CommentSectionProps {
  blogId: string;
}

const CommentSection: React.FC<CommentSectionProps> = ({ blogId }) => {
  const [newComment, setNewComment] = useState('');
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  
  const comments = useSelector((state: RootState) => 
    state.comments.comments[blogId] || []
  );

  const handleSubmitComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim() || !isAuthenticated || !user) return;

    const comment = {
      id: Date.now().toString(),
      content: newComment.trim(),
      author: {
        id: user.id,
        name: user.name,
        avatar: user.avatar,
      },
      blogId,
      createdAt: new Date().toISOString(),
      likes: 0,
      likedBy: [],
    };

    dispatch(addComment(comment));
    setNewComment('');
  };

  const handleLikeComment = (commentId: string) => {
    if (isAuthenticated && user) {
      dispatch(toggleCommentLike({ blogId, commentId, userId: user.id }));
    }
  };

  return (
    <div className="mt-8">
      <div className="bg-white rounded-lg shadow-sm p-8">
        <h3 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
          <MessageCircle className="h-6 w-6 mr-2" />
          Comments ({comments.length})
        </h3>

        {/* Comment Form */}
        {isAuthenticated ? (
          <form onSubmit={handleSubmitComment} className="mb-8">
            <div className="flex space-x-4">
              <img
                src={user?.avatar}
                alt={user?.name}
                className="h-10 w-10 rounded-full object-cover flex-shrink-0"
              />
              <div className="flex-1">
                <textarea
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  placeholder="Share your thoughts..."
                  rows={3}
                  className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none"
                />
                <div className="flex justify-end mt-3">
                  <button
                    type="submit"
                    disabled={!newComment.trim()}
                    className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Send className="h-4 w-4" />
                    <span>Post Comment</span>
                  </button>
                </div>
              </div>
            </div>
          </form>
        ) : (
          <div className="bg-gray-50 rounded-lg p-6 text-center mb-8">
            <p className="text-gray-600 mb-4">Sign in to join the conversation</p>
            <a
              href="/login"
              className="inline-block bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Sign In
            </a>
          </div>
        )}

        {/* Comments List */}
        <div className="space-y-6">
          {comments.length === 0 ? (
            <div className="text-center py-8">
              <MessageCircle className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No comments yet. Be the first to share your thoughts!</p>
            </div>
          ) : (
            comments.map((comment) => (
              <div key={comment.id} className="border border-gray-200 rounded-lg p-6">
                <div className="flex items-start space-x-4">
                  <img
                    src={comment.author.avatar}
                    alt={comment.author.name}
                    className="h-10 w-10 rounded-full object-cover flex-shrink-0"
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h4 className="font-semibold text-gray-900">
                        {comment.author.name}
                      </h4>
                      <span className="text-gray-500 text-sm">
                        {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}
                      </span>
                    </div>
                    <p className="text-gray-700 mb-4 leading-relaxed">
                      {comment.content}
                    </p>
                    <div className="flex items-center space-x-4">
                      <button
                        onClick={() => handleLikeComment(comment.id)}
                        disabled={!isAuthenticated}
                        className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm transition-all duration-200 ${
                          user && comment.likedBy.includes(user.id)
                            ? 'bg-red-50 text-red-600 hover:bg-red-100'
                            : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
                        } ${!isAuthenticated ? 'opacity-50 cursor-not-allowed' : ''}`}
                      >
                        <Heart
                          className={`h-4 w-4 ${
                            user && comment.likedBy.includes(user.id) ? 'fill-current' : ''
                          }`}
                        />
                        <span>{comment.likes}</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

export default CommentSection;