import React, { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, Share2, BookOpen, Edit, Trash2, ArrowLeft } from 'lucide-react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../../store';
import { useAuth } from '../../hooks/useAuth';
import { toggleLike, deleteBlog, setCurrentBlog } from '../../store/slices/blogSlice';
import { setComments } from '../../store/slices/commentSlice';
import { mockComments } from '../../data/mockData';
import CommentSection from './CommentSection';

const BlogDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  
  const blog = useSelector((state: RootState) => 
    state.blogs.blogs.find(b => b.id === id)
  );

  useEffect(() => {
    if (id && blog) {
      dispatch(setCurrentBlog(blog));
      // Load comments for this blog
      if (mockComments[id]) {
        dispatch(setComments({ blogId: id, comments: mockComments[id] }));
      }
    }
  }, [id, blog, dispatch]);

  if (!blog) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900">Blog post not found</h2>
          <p className="text-gray-600 mt-2">The post you're looking for doesn't exist.</p>
          <Link 
            to="/" 
            className="mt-4 inline-block text-blue-600 hover:text-blue-700 transition-colors"
          >
            ← Back to home
          </Link>
        </div>
      </div>
    );
  }

  const handleLike = () => {
    if (isAuthenticated && user) {
      dispatch(toggleLike({ blogId: blog.id, userId: user.id }));
    }
  };

  const handleDelete = () => {
    if (window.confirm('Are you sure you want to delete this post?')) {
      dispatch(deleteBlog(blog.id));
      navigate('/');
    }
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: blog.title,
          text: blog.excerpt,
          url: window.location.href,
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      // Fallback: copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const isLiked = user && blog.likedBy.includes(user.id);
  const canEdit = user && (user.id === blog.author.id || user.role === 'admin');

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back</span>
          </button>
        </div>
      </div>

      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="bg-white rounded-lg shadow-sm overflow-hidden">
          {/* Cover Image */}
          {blog.coverImage && (
            <div className="aspect-video w-full overflow-hidden">
              <img
                src={blog.coverImage}
                alt={blog.title}
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <div className="p-8">
            {/* Meta Info */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center space-x-4">
                <span className="inline-block bg-blue-100 text-blue-800 text-sm px-3 py-1 rounded-full font-medium">
                  {blog.category}
                </span>
                <span className="text-gray-500 text-sm">
                  {formatDistanceToNow(new Date(blog.createdAt), { addSuffix: true })}
                </span>
                <div className="flex items-center space-x-1 text-gray-500 text-sm">
                  <BookOpen className="h-4 w-4" />
                  <span>{Math.ceil(blog.content.replace(/<[^>]*>/g, '').length / 200)} min read</span>
                </div>
              </div>

              {canEdit && (
                <div className="flex items-center space-x-2">
                  <Link
                    to={`/edit/${blog.id}`}
                    className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                  >
                    <Edit className="h-4 w-4" />
                  </Link>
                  <button
                    onClick={handleDelete}
                    className="p-2 text-gray-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              )}
            </div>

            {/* Title */}
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6 leading-tight">
              {blog.title}
            </h1>

            {/* Author Info */}
            <div className="flex items-center space-x-4 mb-8 pb-8 border-b border-gray-200">
              <img
                src={blog.author.avatar}
                alt={blog.author.name}
                className="h-12 w-12 rounded-full object-cover"
              />
              <div className="flex-1">
                <h3 className="font-semibold text-gray-900">{blog.author.name}</h3>
                <p className="text-gray-600 text-sm">Author</p>
              </div>
              <div className="flex items-center space-x-4">
                <button
                  onClick={handleLike}
                  disabled={!isAuthenticated}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200 ${
                    isLiked
                      ? 'bg-red-50 text-red-600 hover:bg-red-100'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  } ${!isAuthenticated ? 'opacity-50 cursor-not-allowed' : ''}`}
                >
                  <Heart className={`h-5 w-5 ${isLiked ? 'fill-current' : ''}`} />
                  <span>{blog.likes}</span>
                </button>
                <button
                  onClick={handleShare}
                  className="flex items-center space-x-2 px-4 py-2 bg-gray-100 text-gray-600 hover:bg-gray-200 rounded-lg transition-colors"
                >
                  <Share2 className="h-5 w-5" />
                  <span>Share</span>
                </button>
              </div>
            </div>

            {/* Tags */}
            <div className="flex flex-wrap gap-2 mb-8">
              {blog.tags.map(tag => (
                <span
                  key={tag}
                  className="inline-block bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm"
                >
                  #{tag}
                </span>
              ))}
            </div>

            {/* Content */}
            <div
              className="prose prose-lg max-w-none"
              dangerouslySetInnerHTML={{ __html: blog.content }}
            />

            {/* Engagement Stats */}
            <div className="flex items-center justify-between mt-8 pt-8 border-t border-gray-200">
              <div className="flex items-center space-x-6">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Heart className="h-5 w-5" />
                  <span>{blog.likes} likes</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <MessageCircle className="h-5 w-5" />
                  <span>{blog.commentsCount} comments</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Comments Section */}
        <CommentSection blogId={blog.id} />
      </article>
    </div>
  );
};

export default BlogDetail;