import React from 'react';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';
import { Heart, MessageCircle, BookOpen } from 'lucide-react';
import { Blog } from '../../store/slices/blogSlice';
import { useAuth } from '../../hooks/useAuth';
import { useDispatch } from 'react-redux';
import { toggleLike } from '../../store/slices/blogSlice';

interface BlogCardProps {
  blog: Blog;
}

const BlogCard: React.FC<BlogCardProps> = ({ blog }) => {
  const { user, isAuthenticated } = useAuth();
  const dispatch = useDispatch();

  const handleLike = (e: React.MouseEvent) => {
    e.preventDefault();
    if (isAuthenticated && user) {
      dispatch(toggleLike({ blogId: blog.id, userId: user.id }));
    }
  };

  const isLiked = user && blog.likedBy.includes(user.id);

  return (
    <article className="bg-white rounded-xl shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden group">
      <Link to={`/blog/${blog.id}`} className="block">
        {blog.coverImage && (
          <div className="aspect-video overflow-hidden">
            <img
              src={blog.coverImage}
              alt={blog.title}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
            />
          </div>
        )}
        
        <div className="p-6">
          <div className="flex items-center space-x-2 mb-3">
            <span className="inline-block bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
              {blog.category}
            </span>
            <span className="text-gray-400 text-xs">•</span>
            <span className="text-gray-500 text-xs">
              {formatDistanceToNow(new Date(blog.createdAt), { addSuffix: true })}
            </span>
          </div>

          <h2 className="text-xl font-bold text-gray-900 mb-2 line-clamp-2 group-hover:text-blue-600 transition-colors">
            {blog.title}
          </h2>

          <p className="text-gray-600 text-sm mb-4 line-clamp-3">
            {blog.excerpt}
          </p>

          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <img
                src={blog.author.avatar}
                alt={blog.author.name}
                className="h-8 w-8 rounded-full object-cover"
              />
              <span className="text-sm text-gray-700 font-medium">
                {blog.author.name}
              </span>
            </div>

            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-1">
                <BookOpen className="h-4 w-4 text-gray-400" />
                <span className="text-xs text-gray-500">
                  {Math.ceil(blog.content.replace(/<[^>]*>/g, '').length / 200)} min read
                </span>
              </div>
            </div>
          </div>
        </div>
      </Link>

      <div className="px-6 pb-4 flex items-center justify-between border-t border-gray-100 pt-4">
        <button
          onClick={handleLike}
          disabled={!isAuthenticated}
          className={`flex items-center space-x-2 px-3 py-1 rounded-full text-sm transition-all duration-200 ${
            isLiked
              ? 'bg-red-50 text-red-600 hover:bg-red-100'
              : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
          } ${!isAuthenticated ? 'opacity-50 cursor-not-allowed' : 'hover:scale-105'}`}
        >
          <Heart className={`h-4 w-4 ${isLiked ? 'fill-current' : ''}`} />
          <span>{blog.likes}</span>
        </button>

        <div className="flex items-center space-x-2 text-gray-500">
          <MessageCircle className="h-4 w-4" />
          <span className="text-sm">{blog.commentsCount}</span>
        </div>
      </div>
    </article>
  );
};

export default BlogCard;