import { useDispatch, useSelector } from 'react-redux';
import { RootState } from '../store';
import { loginStart, loginSuccess, loginFailure, logout, User } from '../store/slices/authSlice';

export const useAuth = () => {
  const dispatch = useDispatch();
  const { user, isAuthenticated, loading } = useSelector((state: RootState) => state.auth);

  const login = async (email: string, password: string) => {
    dispatch(loginStart());
    
    // Simulate API call
    setTimeout(() => {
      if (email && password) {
        const mockUser: User = {
          id: '1',
          name: email === 'admin@blog.com' ? 'Admin User' : 'John Doe',
          email,
          avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
          bio: 'Passionate writer and developer.',
          role: email === 'admin@blog.com' ? 'admin' : 'user',
          joinedAt: '2024-01-01',
        };
        dispatch(loginSuccess(mockUser));
      } else {
        dispatch(loginFailure());
      }
    }, 1000);
  };

  const register = async (name: string, email: string, password: string) => {
    dispatch(loginStart());
    
    // Simulate API call
    setTimeout(() => {
      const mockUser: User = {
        id: Math.random().toString(),
        name,
        email,
        avatar: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150&h=150&dpr=1',
        bio: 'New member of the community.',
        role: 'user',
        joinedAt: new Date().toISOString(),
      };
      dispatch(loginSuccess(mockUser));
    }, 1000);
  };

  const signOut = () => {
    dispatch(logout());
  };

  return {
    user,
    isAuthenticated,
    loading,
    login,
    register,
    signOut,
  };
};