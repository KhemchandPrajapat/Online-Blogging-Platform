/// <reference types="vite/client" />

declare module 'react-quill' {
  import { ComponentType } from 'react';

  interface ReactQuillProps {
    value?: string;
    onChange?: (content: string) => void;
    modules?: Record<string, any>;
    formats?: string[];
    theme?: string;
    placeholder?: string;
    style?: React.CSSProperties;
    ref?: React.Ref<any>;
  }

  const ReactQuill: ComponentType<ReactQuillProps>;
  export default ReactQuill;
}